package com.main.errorreportingsystemserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ErrorReportingSystemServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ErrorReportingSystemServerApplication.class, args);
	}

}

